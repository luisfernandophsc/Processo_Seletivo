#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

struct dados
{
    double longitude;
    double latitude;
    double altitude;
}*log;

struct coordenadas
{
    double graus;
    double minutos;
    double segundos;
    char orient;

}*lati, *longit;

void contagem(int *c, char *caminho)
{
    char linhas, letra='\n';
    FILE *arq = fopen(caminho, "r");
    while(fread(&linhas, sizeof(char), 1, arq))
    {
        if(linhas == letra)
            {
                *c = *c + 1;
            }
    }
    fclose(arq);
}

void leitura(int *c, char *caminho)
{
    int i;
    FILE *arq = fopen(caminho, "r");
    for(i = 0; i<(*c);i++)
    {
        fscanf(arq,"%lf %lf %lf", &log[i].longitude, &log[i].latitude, &log[i].altitude);

    }
    fclose(arq);
}

void converter(int *c)
{
    int i;
    for(i = 0; i<(*c);i++)
    {
        if(log[i].longitude<0)
        {
           longit[i].orient = 'O';
        }
        else
        {
            longit[i].orient = 'L';
        }

        longit[i].graus = abs((int)(log[i].longitude));
        longit[i].minutos = abs(60*log[i].longitude) - 60*longit[i].graus;
        longit[i].segundos = abs(3600.0*log[i].longitude) - 60.0*longit[i].minutos -3600.0*longit[i].graus;



        if(log[i].latitude<0)
        {
           lati[i].orient = 'S';
        }
        else
        {
            lati[i].orient = 'N';
        }

        lati[i].graus = abs((int)(log[i].latitude));
        lati[i].minutos = abs(60*log[i].latitude) - 60*lati[i].graus;
        lati[i].segundos = abs(3600.0*log[i].latitude) - 60.0*lati[i].minutos -3600.0*lati[i].graus;

    }
}

void escrever(int *c)
{
    int i;
    FILE *arq = fopen("conversao.txt", "w");
    for(i = 0; i<(*c);i++)
    {
        fprintf(arq,"%0.0lf� %0.0lf' %0.0lf''%c\t", longit[i].graus, longit[i].minutos, longit[i].segundos, longit[i].orient);
        fprintf(arq,"%0.0lf� %0.0lf' %0.0lf''%c\t", lati[i].graus, lati[i].minutos, lati[i].segundos, lati[i].orient);
        fprintf(arq,"%0.4lf\n", log[i].altitude);
    }
    printf("Os aquivos convertidos podem ser encontrados na mesma pasta que o arquivo execut�vel, com o seguinte nome: 'conversao.txt'.\n");
    fclose(arq);
}

void max_min_med(int *c)
{
    int i;
    int max = 0, min = 0;
    double media = (log[0].altitude)/(*c);
    printf("Dados de altitude:\n");
    for(i = 1; i<(*c);i++)
    {
        if(log[i].altitude>log[max].altitude)
        {
            max = i;
        }

        if(log[i].altitude<log[min].altitude)
        {
            min = i;
        }

        media = media + (log[i].altitude)/(*c);
    }


    printf("Altitude m�xima: %0.4lf\nAltitude m�nima: %0.4lf\nAltitude m�dia:  %0.4lf\n\n", log[max].altitude, log[min].altitude, media);
}

void inicio(char *caminho)
{
    printf("Informe o caminho para o arquivo de log:\n(se o arquivo estiver na mesma pasta do execut�vel, basta inserir apenas seu nome\ncom a extens�o '.txt', como por exemplo 'geotag_file.txt')\n\n");
    scanf("%s", caminho);
    printf("\n\n");
}

int main()
{
    setlocale(LC_CTYPE, "portuguese");
    int cont= 0;
    char caminho[255];
    inicio(&caminho);                                   //Pede ao usu�rio o caminho do arquivo de log
    contagem(&cont, &caminho);                          //Realiza a contagem de linhas do arquivo e armazena na vari�vel cont
    log = malloc(cont*sizeof(struct dados));            //aloca espa�o de mem�ria para a estrutura "log" de acordo com o n�mero de linhas
    lati = malloc(cont*sizeof(struct coordenadas));     //aloca espa�o de mem�ria para a estrutura "lati" de acordo com o n�mero de linhas
    longit = malloc(cont*sizeof(struct coordenadas));   //aloca espa�o de mem�ria para a estrutura "longit" de acordo com o n�mero de linhas
    leitura(&cont, &caminho);                           //Realiza leitura dos dados do arquivo e os armazena em um vetor de estrutura
    max_min_med(&cont);                                 //Calcula o valor m�ximo, m�nimo e m�dio de altitude e mostra ao usu�rio
    converter(&cont);                                   //Converte os valores de latitude e longitude para grau, minuto e segundo
    escrever(&cont);                                    //Escreve em um arquivo os dados convertidos
    getch();

    return 0;
}
